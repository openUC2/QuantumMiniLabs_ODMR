G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.4*
G04 #@! TF.CreationDate,2025-09-22T15:24:31+02:00*
G04 #@! TF.ProjectId,antenna-with-diamonds,616e7465-6e6e-4612-9d77-6974682d6469,A*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.4) date 2025-09-22 15:24:31*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,0.000000*%
%ADD11RoundRect,0.200100X0.949900X-0.949900X0.949900X0.949900X-0.949900X0.949900X-0.949900X-0.949900X0*%
%ADD12C,2.200000*%
%ADD13RoundRect,0.250000X-0.262500X-0.450000X0.262500X-0.450000X0.262500X0.450000X-0.262500X0.450000X0*%
G04 APERTURE END LIST*
D10*
G36*
X120000020Y-111500000D02*
G01*
X108000000Y-111500000D01*
X108000000Y-108500000D01*
X120000020Y-108500000D01*
X120000020Y-111500000D01*
G37*
D11*
G04 #@! TO.C,J101*
X104000000Y-110000000D03*
D12*
X101450000Y-112550000D03*
X106550000Y-112550000D03*
X101450000Y-107450000D03*
X106550000Y-107450000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,R101*
X121987500Y-110000000D03*
X123812500Y-110000000D03*
G04 #@! TD*
M02*
